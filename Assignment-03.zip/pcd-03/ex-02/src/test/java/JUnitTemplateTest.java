import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Model a template test with junit.
 */
public class JUnitTemplateTest {
    @Test public void JUnitIsWorking(){ assertTrue(true); }
}
