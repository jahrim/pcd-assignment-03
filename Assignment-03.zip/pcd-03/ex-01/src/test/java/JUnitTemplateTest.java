import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Model a template test with junit.
 */
public class JUnitTemplateTest {
    @Test public void JUnitIsWorking(){ assertTrue(true); }
}