package util.exception;

public class NullVectorException extends Exception { }