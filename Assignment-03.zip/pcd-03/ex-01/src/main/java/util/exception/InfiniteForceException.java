package util.exception;

public class InfiniteForceException extends Exception { }