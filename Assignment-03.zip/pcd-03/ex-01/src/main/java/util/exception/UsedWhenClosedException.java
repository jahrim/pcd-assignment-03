package util.exception;

public class UsedWhenClosedException extends Exception { }